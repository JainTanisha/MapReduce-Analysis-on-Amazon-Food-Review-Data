/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amazoninvertedindex;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author Tanisha_Jain
 */
public class AmazonInvertedIndex {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws IOException, InterruptedException, ClassNotFoundException {
        // TODO code application logic here
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf,"Inverted Index");
        job.setJarByClass(AmazonInvertedIndex.class);
        job.setMapperClass(InvertedMapper.class);
        job.setReducerClass(InvertedReducer.class);
        
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);
        
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
    
    public static class InvertedMapper extends Mapper<LongWritable, Text, Text, Text>{
        
        private Text product = new Text();
        private Text userId = new Text();
        
        public void map(LongWritable key, Text values, Context context){
            
            if(key.get()==0){
                return;
            }
            
            try{
            String[] tokens = values.toString().split(",");
            
            userId.set(tokens[2]);
            product.set(tokens[1]);
            
            context.write(product, userId);
            }
            catch(IOException | InterruptedException ex){
                System.out.println("Error in Mapper" + ex.getMessage());
            }
        }
    }
    
    public static class InvertedReducer extends Reducer<Text,Text,Text,Text>{
        
        private Text result = new Text();
        
        @Override
        public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException{
        
        StringBuilder sb=new StringBuilder();
        boolean first = true;
        
        for(Text id:values){
        if(first){
            first = false;
        }
        else{
            sb.append("    ");
            
        }
        sb.append(id.toString());
    }
        result.set(sb.toString());
        context.write(key, result);
    }
  }    
}
