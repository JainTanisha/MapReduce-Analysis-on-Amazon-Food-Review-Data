/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amazontopproducts;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author Tanisha_Jain
 */
public class AmazonTopProducts {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
       
         Configuration conf1 = new Configuration();
         Job job1 = Job.getInstance(conf1,"Top 100 Products");
         job1.setJarByClass(AmazonTopProducts.class);
         job1.setMapperClass(Map1.class);
         job1.setMapOutputKeyClass(Text.class);
         job1.setMapOutputValueClass(FloatWritable.class);
        
         job1.setReducerClass(Reduce1.class);
         job1.setOutputKeyClass(Text.class);
         job1.setOutputValueClass(FloatWritable.class);
        
         FileInputFormat.addInputPath(job1, new Path(args[0]));
         FileOutputFormat.setOutputPath(job1, new Path(args[1]));
        
         boolean complete = job1.waitForCompletion(true);
        
         Configuration conf2 = new Configuration();
        
        
         if(complete){
         Job job2 = Job.getInstance(conf2,"Top 100 Products");
         job2.setJarByClass(AmazonTopProducts.class);
         job2.setMapperClass(Map2.class);
         job2.setMapOutputKeyClass(FloatWritable.class);
         job2.setMapOutputValueClass(Text.class);
        
         job2.setSortComparatorClass(GroupComparator.class);
        
         job2.setReducerClass(Reduce2.class);
         job2.setOutputKeyClass(FloatWritable.class);
         job2.setOutputValueClass(Text.class);
        
         FileInputFormat.addInputPath(job2, new Path(args[1]));
         FileOutputFormat.setOutputPath(job2, new Path(args[2]));
         
         System.exit(job2.waitForCompletion(true) ? 0 : 1);
         }        
    }
    
    public static class Map1 extends Mapper<LongWritable, Text, Text, FloatWritable>{
        
        private Text text = new Text();
        private FloatWritable score = new FloatWritable();
        
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
            
            if(key.get()==0){
            return;
            }
            
            else{
            
            String[] line = value.toString().split(",");
            String productId = line[1].trim();
            float ratingVal = Float.valueOf(line[6].trim());
            
            text.set(productId);
            score.set(ratingVal);
            
            context.write(text, score);
            
            }
        }
    }
    
      public static class Reduce1 extends Reducer<Text, FloatWritable, Text, FloatWritable>{
        
        private FloatWritable result = new FloatWritable();
        
        @Override
        protected void reduce(Text key, Iterable<FloatWritable> values, Context context) throws IOException, InterruptedException{
           
            float sum = 0;
            int count = 0;
            for(FloatWritable val:values){
                sum+=val.get();
                count = count+1;
            }
            
            float average = sum/count;
            
            result.set(average);
            context.write(key,result);
        }
    }
   
    public static class Map2 extends Mapper<LongWritable, Text, FloatWritable, Text>
    {
        public void map(LongWritable key, Text value,Context context){
            
            String[] row = value.toString().split("\\t");
            String productId = row[0].trim();
            float prodRating = Float.parseFloat(row[1].trim());
           
            try{
                Text id = new Text(productId);
                FloatWritable prodRate = new FloatWritable(prodRating);
                context.write(prodRate,id);
               
            }catch(Exception e){
               
            }
        }
    }
   
    public static class GroupComparator extends WritableComparator {
   
            protected GroupComparator()
            {
                super(FloatWritable.class,true);
            }
               
            public int compare(WritableComparable w1, WritableComparable w2)
                {
                    FloatWritable cw1 = (FloatWritable) w1;
                    FloatWritable cw2 = (FloatWritable) w2;
                    int result = cw1.get() < cw2.get() ? 1 : cw1.get() == cw2.get() ? 0 : -1;
                    return result;
                }
    }
   
   
    public static class Reduce2 extends Reducer<FloatWritable, Text, FloatWritable, Text>{
        
        int count=0;
        public void reduce(FloatWritable key, Iterable<Text> value,Context context)
                throws IOException, InterruptedException{
           
            for(Text val: value){
               
            if(count<100)
            {
                context.write(key,val);
            }
                count++;
        }
    }
   
    
    }
    
}
