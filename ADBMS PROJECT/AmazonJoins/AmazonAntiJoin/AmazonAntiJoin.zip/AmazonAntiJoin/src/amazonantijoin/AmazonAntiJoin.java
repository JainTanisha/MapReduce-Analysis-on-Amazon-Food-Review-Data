/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amazonantijoin;

import java.io.IOException;
import java.util.ArrayList;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

/**
 *
 * @author Tanisha_Jain
 */
public class AmazonAntiJoin {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
        
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Anti Join");
        job.setJarByClass(AmazonAntiJoin.class);

        MultipleInputs.addInputPath(job, new Path(args[0]), TextInputFormat.class, InnerJoinMapper1.class);
        MultipleInputs.addInputPath(job, new Path(args[1]), TextInputFormat.class, InnerJoinMapper2.class);
        job.getConfiguration().set("join.type", "antijoin");
        //job.setNumReduceTasks(0);
        job.setReducerClass(UserRatingIdReducer.class);

        job.setOutputFormatClass(TextOutputFormat.class);
        TextOutputFormat.setOutputPath(job, new Path(args[2]));

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        System.exit(job.waitForCompletion(true)? 0: 2);
    }
    
      public static class InnerJoinMapper1 extends Mapper<LongWritable, Text, Text, Text>{
        
        private Text outkey = new Text();
        private Text outvalue = new Text();
        
        public void map(LongWritable key, Text value, Mapper.Context context) throws IOException, InterruptedException{
            
            if(key.get()==0){
                return;
            }
            
            //UserIds in Amazon Fine Food Review
            String[] separatedInput = value.toString().split(",");
            String userId = separatedInput[2].trim();
            
            if(userId== null) {
                return;
            }
            
            outkey.set(userId);
            // Flag this record for the reducer and then output
            outvalue.set("A" + value.toString());
            context.write(outkey, outvalue);
        }
    }
      
        public static class InnerJoinMapper2 extends Mapper<LongWritable, Text, Text, Text> {

            private Text outkey = new Text();
            private Text outvalue = new Text();

            public void map(LongWritable key, Text value, Mapper.Context context) throws IOException, InterruptedException {
           
            if(key.get()==0){
                return;
            }    
            //UserId in User Profiles
            String[] separatedInput = value.toString().split(",");
            String ratingId = separatedInput[1];
            if (ratingId == null) {
                return;
            }
            // The foreign join key is the user ID
            outkey.set(ratingId);
            // Flag this record for the reducer and then output
            outvalue.set("B" + value.toString());
            context.write(outkey, outvalue);
        }
    }
        
        public static class UserRatingIdReducer extends Reducer<Text, Text, Text, Text>{
            
        private static final Text EMPTY_TEXT = new Text("");
        private Text tmp = new Text();
        private ArrayList<Text> listA = new ArrayList<Text>();
        private ArrayList<Text> listB = new ArrayList<Text>();
        
        private String joinType = null;

        public void setup(Reducer.Context context) {
            
            // Get the type of join from our configuration
            joinType = context.getConfiguration().get("join.type");
        }
        
         public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
         
            //Clearing the lists 
            listA.clear();
            listB.clear();
            
              while (values.iterator().hasNext()) {
                tmp = values.iterator().next();
                
                if (Character.toString((char) tmp.charAt(0)).equals("A")) {

                    listA.add(new Text(tmp.toString().substring(1)));
                }
                if (Character.toString((char) tmp.charAt(0)).equals("B")) {
                  
                    listB.add(new Text(tmp.toString().substring(1)));
                }
              
            }
            executeJoinLogic(context);
        }
        
        private void executeJoinLogic(Context context) throws IOException, InterruptedException{
            
          //This is removal of common attributes of 2 files from a whole joining of 2 files
          //anti join = full outer join - inner join;
           if (joinType.equalsIgnoreCase("antijoin")) {
                if (listA.isEmpty() ^ listB.isEmpty()) {
                    
                    for (Text A : listA) {
                        context.write(A, EMPTY_TEXT);
                    }
                    for (Text B : listB) {
                        context.write(EMPTY_TEXT, B);
                    }
                }
            }
            
            
        }
        
        }         
    
}
